export const PI = 3.14;

export function calculateCirumcumference(diameter: number) {
    return diameter * PI;
}