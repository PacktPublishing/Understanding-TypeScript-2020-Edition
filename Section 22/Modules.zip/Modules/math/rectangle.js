"use strict";
function calculateRectangle(width, length) {
    return width * length;
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = calculateRectangle;
