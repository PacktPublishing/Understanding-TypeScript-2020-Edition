export default function calculateRectangle(width: number, length: number) {
    return width * length;
}