"use strict";
exports.PI = 3.14;
function calculateCirumcumference(diameter) {
    return diameter * exports.PI;
}
exports.calculateCirumcumference = calculateCirumcumference;
