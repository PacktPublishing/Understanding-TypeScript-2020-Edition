import $ = require("jquery");
$("#app").css({"background-color": "green"});
