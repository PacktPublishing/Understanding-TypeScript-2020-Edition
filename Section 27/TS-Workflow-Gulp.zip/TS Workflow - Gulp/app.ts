import "jQuery";
$("#app").css({"background-color": "blue"});
