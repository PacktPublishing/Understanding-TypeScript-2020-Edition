const userName = 'Maximilian';

console.log(userName);