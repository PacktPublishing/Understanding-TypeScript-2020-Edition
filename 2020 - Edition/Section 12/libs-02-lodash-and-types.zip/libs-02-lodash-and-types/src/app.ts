import _ from 'lodash';

console.log(_.shuffle([1, 2, 3]));
