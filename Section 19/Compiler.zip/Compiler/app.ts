let myName: string = "Max";
let myAge: number = 27;
let anything;
anything = 12;

// myName = 30;